package com.Fiap.Castillo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginInfo")
public class HelloWorldServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
 
    public HelloWorldServlet() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String id = request.getParameter("name");
    	response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	request.setAttribute(id, "name");
    	if(id.length() > 0){
    		out.println("<style>"
    				+ "p { padding-left: 15px; margin-top: 0px; }"
    				+ "h3 { margin-bottom: 0px; }"
    				+ "</style>");
    		out.println("<h1>Ol� " + id + ". Olhe s� nossa lista de cadastrados atualizada:</h1><br>");
    		insertName(id);
    		listNames(out);
    		out.println("<h1>:)</h1><br>");
    	} else {
    		out.println("<b>Invalid Login Info.</b><br>");
    	}
    	out.close();
    }
    
    protected void insertName(String name) {
    	try {
    		ConectaBanco.getConexaoMySQL();
    		ConectaBanco.statement.executeUpdate("INSERT INTO fiap.user VALUES ('" + name + "', NOW());");
    		ConectaBanco.FecharConexao();
    	} catch (SQLException e) {
    	    throw new IllegalStateException("Cannot connect the database!", e);
    	}
    }
    
    protected void listNames(PrintWriter out) {
    	try {
    		ConectaBanco.getConexaoMySQL();
    		ResultSet rs = ConectaBanco.statement.executeQuery("select * from user");
    		while(rs.next()) {
    			out.println("<h3>" + rs.getString("name") + "</h3> <p><b>Data:</b> " + rs.getTimestamp("date") + "</p>");
    		}
    		ConectaBanco.FecharConexao();
    	} catch (Exception e) {}
    }
}
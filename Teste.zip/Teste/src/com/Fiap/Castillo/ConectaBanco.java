package com.Fiap.Castillo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConectaBanco {
	public static String status = "N�o conectou...";
	public static Connection connection = null;
	public static Statement statement = null;
	
	public ConectaBanco() {

	}

	public static void getConexaoMySQL() {	
		try {
			String serverName = "localhost:3306";
			String mydatabase ="fiap";
			String username = "root";
			String password = "Brasil@77";
			String url = "jdbc:mysql://" + serverName + "/" + mydatabase;
			
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(url, username, password);
			
			if (connection != null) {
				status = ("STATUS--->Conectado com sucesso!");
			} else {
				status = ("STATUS--->N�o foi possivel realizar conex�o");
			}
			
			statement = connection.createStatement();
		} catch (ClassNotFoundException e) {
			status = "O driver expecificado nao foi encontrado.";
		} catch (SQLException e) {
			status = "Nao foi possivel conectar ao Banco de Dados.";
		}
	}

	public static String statusConection() {
		return status;
	}

	public static boolean FecharConexao() {
		try {
			ConectaBanco.connection.close();
			return true;
		} catch (SQLException e) {
			return false;
		}
	}
	
	public static void ReiniciarConexao() {
		FecharConexao();
		ConectaBanco.getConexaoMySQL();
	}
}

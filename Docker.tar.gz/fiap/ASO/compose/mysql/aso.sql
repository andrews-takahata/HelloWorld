use fiapdb;
create table Aso (id INT(6) PRIMARY KEY, name VARCHAR(30) NOT NULL);
insert into Aso values (1234, "Jose Castillo Lema");
